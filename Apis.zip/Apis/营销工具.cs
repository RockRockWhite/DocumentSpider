
        #region Apache License Version 2.0
        /*----------------------------------------------------------------

        Copyright 2022 Jeffrey Su & Suzhou Senparc Network Technology Co.,Ltd.

        Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file
        except in compliance with the License. You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

        Unless required by applicable law or agreed to in writing, software distributed under the
        License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
        either express or implied. See the License for the specific language governing permissions
        and limitations under the License.

        Detail: https://github.com/JeffreySu/WeiXinMPSDK/blob/master/license.md

        ----------------------------------------------------------------*/
        #endregion Apache License Version 2.0

        /*----------------------------------------------------------------
            Copyright (C) 2022 Senparc
        
            文件名：营销工具.cs
            文件功能描述：微信支付V3服务商平台接口
            
            创建标识：Senparc - 20220804

        ----------------------------------------------------------------*/

        using Senparc.CO2NET.Helpers;
        using Senparc.CO2NET.Trace;
        using Senparc.Weixin.Entities;
        // TODO: 引入Entities
        // using Senparc.Weixin.TenPayV3.Apis.BasePay;
        // using Senparc.Weixin.TenPayV3.Apis.Entities;
        // using Senparc.Weixin.TenPayV3.Entities;
        // using Senparc.Weixin.TenPayV3.Helpers;
        using System;
        using System.IO;
        using System.Linq;
        using System.Runtime.InteropServices.ComTypes;
        using System.Security.Cryptography;
        using System.Text;
        using System.Threading.Tasks;

        namespace Senparc.Weixin.ServiceProviderTenPayV3.Apis{
            public class 营销工具{

                private ISenparcWeixinSettingForTenpayV3 _tenpayV3Setting;

                /// <summary>
                /// 构造函数
                /// </summary>
                /// <param name="senparcWeixinSettingForTenpayV3"></param>
                public 营销工具(ISenparcWeixinSettingForTenpayV3 senparcWeixinSettingForTenpayV3 = null)
                {
                    _tenpayV3Setting = senparcWeixinSettingForTenpayV3 ?? Senparc.Weixin.Config.SenparcWeixinSetting.TenpayV3Setting;

                }

                /// <summary>
                /// 返回可用的微信支付地址（自动判断是否使用沙箱）
                /// </summary>
                /// <param name="urlFormat">如：<code>https://api.mch.weixin.qq.com/pay/unifiedorder</code></param>
                /// <returns></returns>
                internal static string GetPayApiUrl(string urlFormat)
                {
                    //注意：目前微信支付 V3 还没有支持沙箱，此处只是预留
                    return string.Format(urlFormat, Senparc.Weixin.Config.UseSandBoxPay ? "sandboxnew/" : "");
                }
            

            #region 代金券  

            

            /// <summary>
            /// 创建代金券批次
            /// </summary>
            /// <param name="data">创建代金券批次需要POST的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter9_1_1Async(chapter9_1_1RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter9_1_1Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/marketing/favor/coupon-stocks");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
            }
        


            /// <summary>
            /// 激活代金券批次
            /// </summary>
            /// <param name="data">激活代金券批次需要POST的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter9_1_3Async(chapter9_1_3RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter9_1_3Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/marketing/favor/stocks/{stock_id}/start");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
            }
        


            /// <summary>
            /// 发放代金券批次
            /// </summary>
            /// <param name="data">发放代金券批次需要POST的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter9_1_2Async(chapter9_1_2RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter9_1_2Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/marketing/favor/users/{openid}/coupons");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
            }
        


            /// <summary>
            /// 暂停代金券批次
            /// </summary>
            /// <param name="data">暂停代金券批次需要POST的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter9_1_13Async(chapter9_1_13RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter9_1_13Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/marketing/favor/stocks/{stock_id}/pause");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
            }
        


            /// <summary>
            /// 重启代金券批次
            /// </summary>
            /// <param name="data">重启代金券批次需要POST的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter9_1_14Async(chapter9_1_14RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter9_1_14Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/marketing/favor/stocks/{stock_id}/restart");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
            }
        


            /// <summary>
            /// 条件查询批次列表
            /// </summary>
            /// <param name="data">条件查询批次列表需要GET的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter9_1_4Async(chapter9_1_4RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter9_1_4Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/marketing/favor/stocks");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.GET, checkSign: false);
            }
        


            /// <summary>
            /// 查询批次详情
            /// </summary>
            /// <param name="data">查询批次详情需要GET的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter9_1_5Async(chapter9_1_5RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter9_1_5Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/marketing/favor/stocks/{stock_id}");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.GET, checkSign: false);
            }
        





            /// <summary>
            /// 根据商户号查用户的券
            /// </summary>
            /// <param name="data">根据商户号查用户的券需要GET的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter9_1_9Async(chapter9_1_9RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter9_1_9Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/marketing/favor/users/{openid}/coupons");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.GET, checkSign: false);
            }
        





            #endregion

            
            #region 商家券

            

            /// <summary>
            /// 创建商家券
            /// </summary>
            /// <param name="data">创建商家券需要POST的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter9_2_1Async(chapter9_2_1RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter9_2_1Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/marketing/busifavor/stocks");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
            }
        


            /// <summary>
            /// 查询商家券详情
            /// </summary>
            /// <param name="data">查询商家券详情需要GET的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter9_2_2Async(chapter9_2_2RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter9_2_2Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/marketing/busifavor/stocks/{stock_id}");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.GET, checkSign: false);
            }
        


            /// <summary>
            /// 核销用户券
            /// </summary>
            /// <param name="data">核销用户券需要POST的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter9_2_3Async(chapter9_2_3RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter9_2_3Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/marketing/busifavor/coupons/use ");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
            }
        


            /// <summary>
            /// 根据过滤条件查询用户券
            /// </summary>
            /// <param name="data">根据过滤条件查询用户券需要GET的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter9_2_4Async(chapter9_2_4RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter9_2_4Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/marketing/busifavor/users/{openid}/coupons");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.GET, checkSign: false);
            }
        


            /// <summary>
            /// 查询用户单张券详情
            /// </summary>
            /// <param name="data">查询用户单张券详情需要GET的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter9_2_5Async(chapter9_2_5RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter9_2_5Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/marketing/busifavor/users/{openid}/coupons/{coupon_code}/appids/{appid}");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.GET, checkSign: false);
            }
        


            /// <summary>
            /// 上传预存code
            /// </summary>
            /// <param name="data">上传预存code需要POST的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter9_2_6Async(chapter9_2_6RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter9_2_6Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/marketing/busifavor/stocks/{stock_id}/couponcodes");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
            }
        


            /// <summary>
            /// 设置商家券事件通知地址
            /// </summary>
            /// <param name="data">设置商家券事件通知地址需要POST的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter9_2_7Async(chapter9_2_7RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter9_2_7Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/marketing/busifavor/callbacks");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
            }
        


            /// <summary>
            /// 查询商家券事件通知地址
            /// </summary>
            /// <param name="data">查询商家券事件通知地址需要GET的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter9_2_8Async(chapter9_2_8RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter9_2_8Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/marketing/busifavor/callbacks");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.GET, checkSign: false);
            }
        


            /// <summary>
            /// 关联订单信息
            /// </summary>
            /// <param name="data">关联订单信息需要 POST的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter9_2_9Async(chapter9_2_9RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter9_2_9Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/marketing/busifavor/coupons/associate");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod. POST, checkSign: false);
            }
        


            /// <summary>
            /// 取消关联订单信息
            /// </summary>
            /// <param name="data">取消关联订单信息需要 POST的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter9_2_10Async(chapter9_2_10RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter9_2_10Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/marketing/busifavor/coupons/disassociate");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod. POST, checkSign: false);
            }
        


            /// <summary>
            /// 修改批次预算
            /// </summary>
            /// <param name="data">修改批次预算需要Patch的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter9_2_11Async(chapter9_2_11RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter9_2_11Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/marketing/busifavor/stocks/{stock_id}/budget");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.Patch, checkSign: false);
            }
        


            /// <summary>
            /// 修改商家券基本信息
            /// </summary>
            /// <param name="data">修改商家券基本信息需要Patch的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter9_2_12Async(chapter9_2_12RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter9_2_12Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/marketing/busifavor/stocks/{stock_id}");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.Patch, checkSign: false);
            }
        


            /// <summary>
            /// 申请退券
            /// </summary>
            /// <param name="data">申请退券需要POST的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter9_2_13Async(chapter9_2_13RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter9_2_13Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/marketing/busifavor/coupons/return");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
            }
        


            /// <summary>
            /// 使券失效
            /// </summary>
            /// <param name="data">使券失效需要POST的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter9_2_14Async(chapter9_2_14RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter9_2_14Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/marketing/busifavor/coupons/deactivate");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
            }
        


            /// <summary>
            /// 营销补差付款
            /// </summary>
            /// <param name="data">营销补差付款需要POST的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter9_2_16Async(chapter9_2_16RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter9_2_16Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/marketing/busifavor/subsidy/pay-receipts");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
            }
        


            /// <summary>
            /// 查询营销补差付款单详情
            /// </summary>
            /// <param name="data">查询营销补差付款单详情需要GET的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter9_2_18Async(chapter9_2_18RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter9_2_18Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/marketing/busifavor/subsidy/pay-receipts/{subsidy_receipt_id}");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.GET, checkSign: false);
            }
        


            #endregion

            
            #region 委托营销

            

            /// <summary>
            /// 建立合作关系
            /// </summary>
            /// <param name="data">建立合作关系需要POST的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter9_5_1Async(int timeOut = Config.TIME_OUT)
            {
                var url = chapter9_5_1Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/marketing/partnerships/build");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, null , timeOut, ApiRequestMethod.POST, checkSign: false);
            }
        


            /// <summary>
            /// 查询合作关系列表
            /// </summary>
            /// <param name="data">查询合作关系列表需要GET的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter9_5_3Async(chapter9_5_3RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter9_5_3Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/marketing/partnerships ");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.GET, checkSign: false);
            }
        

            #endregion

            
            #region 支付有礼

            

            /// <summary>
            /// 创建全场满额送活动
            /// </summary>
            /// <param name="data">创建全场满额送活动需要POST的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter9_7_2Async(chapter9_7_2RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter9_7_2Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/marketing/paygiftactivity/unique-threshold-activity");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
            }
        


            /// <summary>
            /// 查询活动详情接口
            /// </summary>
            /// <param name="data">查询活动详情接口需要GET的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter9_7_4Async(chapter9_7_4RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter9_7_4Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/marketing/paygiftactivity/activities/{activity_id} ");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.GET, checkSign: false);
            }
        


            /// <summary>
            /// 查询活动发券商户号
            /// </summary>
            /// <param name="data">查询活动发券商户号需要GET的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter9_7_5Async(chapter9_7_5RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter9_7_5Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/marketing/paygiftactivity/activities/{activity_id}/merchants");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.GET, checkSign: false);
            }
        


            /// <summary>
            /// 查询活动指定商品列表
            /// </summary>
            /// <param name="data">查询活动指定商品列表需要GET的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter9_7_6Async(chapter9_7_6RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter9_7_6Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/marketing/paygiftactivity/activities/{activity_id}/goods");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.GET, checkSign: false);
            }
        


            /// <summary>
            /// 终止活动
            /// </summary>
            /// <param name="data">终止活动需要POST的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter9_7_7Async(chapter9_7_7RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter9_7_7Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/marketing/paygiftactivity/activities/{activity_id}/terminate");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
            }
        


            /// <summary>
            /// 新增活动发券商户号
            /// </summary>
            /// <param name="data">新增活动发券商户号需要POST的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter9_7_8Async(chapter9_7_8RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter9_7_8Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/marketing/paygiftactivity/activities/{activity_id}/merchants/add");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
            }
        


            /// <summary>
            /// 获取支付有礼活动列表
            /// </summary>
            /// <param name="data">获取支付有礼活动列表需要GET的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter9_7_9Async(chapter9_7_9RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter9_7_9Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/marketing/paygiftactivity/activities");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.GET, checkSign: false);
            }
        


            /// <summary>
            /// 删除活动发券商户号
            /// </summary>
            /// <param name="data">删除活动发券商户号需要POST的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter9_7_10Async(chapter9_7_10RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter9_7_10Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/marketing/paygiftactivity/activities/{activity_id}/merchants/delete");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
            }
        

            #endregion

            }
}

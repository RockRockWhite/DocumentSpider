
        #region Apache License Version 2.0
        /*----------------------------------------------------------------

        Copyright 2022 Jeffrey Su & Suzhou Senparc Network Technology Co.,Ltd.

        Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file
        except in compliance with the License. You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

        Unless required by applicable law or agreed to in writing, software distributed under the
        License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
        either express or implied. See the License for the specific language governing permissions
        and limitations under the License.

        Detail: https://github.com/JeffreySu/WeiXinMPSDK/blob/master/license.md

        ----------------------------------------------------------------*/
        #endregion Apache License Version 2.0

        /*----------------------------------------------------------------
            Copyright (C) 2022 Senparc
        
            文件名：商户进件.cs
            文件功能描述：微信支付V3服务商平台接口
            
            创建标识：Senparc - 20220804

        ----------------------------------------------------------------*/

        using Senparc.CO2NET.Helpers;
        using Senparc.CO2NET.Trace;
        using Senparc.Weixin.Entities;
        // TODO: 引入Entities
        // using Senparc.Weixin.TenPayV3.Apis.BasePay;
        // using Senparc.Weixin.TenPayV3.Apis.Entities;
        // using Senparc.Weixin.TenPayV3.Entities;
        // using Senparc.Weixin.TenPayV3.Helpers;
        using System;
        using System.IO;
        using System.Linq;
        using System.Runtime.InteropServices.ComTypes;
        using System.Security.Cryptography;
        using System.Text;
        using System.Threading.Tasks;

        namespace Senparc.Weixin.ServiceProviderTenPayV3.Apis{
            public class 商户进件{

                private ISenparcWeixinSettingForTenpayV3 _tenpayV3Setting;

                /// <summary>
                /// 构造函数
                /// </summary>
                /// <param name="senparcWeixinSettingForTenpayV3"></param>
                public 商户进件(ISenparcWeixinSettingForTenpayV3 senparcWeixinSettingForTenpayV3 = null)
                {
                    _tenpayV3Setting = senparcWeixinSettingForTenpayV3 ?? Senparc.Weixin.Config.SenparcWeixinSetting.TenpayV3Setting;

                }

                /// <summary>
                /// 返回可用的微信支付地址（自动判断是否使用沙箱）
                /// </summary>
                /// <param name="urlFormat">如：<code>https://api.mch.weixin.qq.com/pay/unifiedorder</code></param>
                /// <returns></returns>
                internal static string GetPayApiUrl(string urlFormat)
                {
                    //注意：目前微信支付 V3 还没有支持沙箱，此处只是预留
                    return string.Format(urlFormat, Senparc.Weixin.Config.UseSandBoxPay ? "sandboxnew/" : "");
                }
            

            #region 特约商户进件

            

            /// <summary>
            /// 提交申请单
            /// </summary>
            /// <param name="data">提交申请单需要POST的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter11_1_1Async(chapter11_1_1RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter11_1_1Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/applyment4sub/applyment/");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
            }
        



            /// <summary>
            /// 修改结算账号
            /// </summary>
            /// <param name="data">修改结算账号需要POST的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter11_1_3Async(chapter11_1_3RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter11_1_3Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/apply4sub/sub_merchants/{sub_mchid}/modify-settlement");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
            }
        


            /// <summary>
            /// 查询结算账号
            /// </summary>
            /// <param name="data">查询结算账号需要GET的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter11_1_4Async(chapter11_1_4RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter11_1_4Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/apply4sub/sub_merchants/{sub_mchid}/settlement");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.GET, checkSign: false);
            }
        

            #endregion

            }
}

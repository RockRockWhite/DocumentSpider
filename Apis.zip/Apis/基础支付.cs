
#region Apache License Version 2.0
/*----------------------------------------------------------------

Copyright 2022 Jeffrey Su & Suzhou Senparc Network Technology Co.,Ltd.

Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file
except in compliance with the License. You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software distributed under the
License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
either express or implied. See the License for the specific language governing permissions
and limitations under the License.

Detail: https://github.com/JeffreySu/WeiXinMPSDK/blob/master/license.md

----------------------------------------------------------------*/
#endregion Apache License Version 2.0

/*----------------------------------------------------------------
    Copyright (C) 2022 Senparc

    文件名：基础支付.cs
    文件功能描述：微信支付V3服务商平台接口

    创建标识：Senparc - 20220804

----------------------------------------------------------------*/

using Senparc.CO2NET.Helpers;
using Senparc.CO2NET.Trace;
using Senparc.Weixin.Entities;
// TODO: 引入Entities
// using Senparc.Weixin.TenPayV3.Apis.BasePay;
// using Senparc.Weixin.TenPayV3.Apis.Entities;
// using Senparc.Weixin.TenPayV3.Entities;
// using Senparc.Weixin.TenPayV3.Helpers;
using System;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Senparc.Weixin.ServiceProviderTenPayV3.Apis
{
    public class 基础支付
    {

        private ISenparcWeixinSettingForTenpayV3 _tenpayV3Setting;

        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="senparcWeixinSettingForTenpayV3"></param>
        public 基础支付(ISenparcWeixinSettingForTenpayV3 senparcWeixinSettingForTenpayV3 = null)
        {
            _tenpayV3Setting = senparcWeixinSettingForTenpayV3 ?? Senparc.Weixin.Config.SenparcWeixinSetting.TenpayV3Setting;

        }

        /// <summary>
        /// 返回可用的微信支付地址（自动判断是否使用沙箱）
        /// </summary>
        /// <param name="urlFormat">如：<code>https://api.mch.weixin.qq.com/pay/unifiedorder</code></param>
        /// <returns></returns>
        internal static string GetPayApiUrl(string urlFormat)
        {
            //注意：目前微信支付 V3 还没有支持沙箱，此处只是预留
            return string.Format(urlFormat, Senparc.Weixin.Config.UseSandBoxPay ? "sandboxnew/" : "");
        }


        #region JSAPI支付



        /// <summary>
        /// JSAPI下单
        /// </summary>
        /// <param name="data">JSAPI下单需要POST的Data数据</param>
        /// <param name="timeOut"></param>
        /// <returns></returns>
        public async Task<ResultJsonBase> chapter4_1_1Async(chapter4_1_1RequestData data, int timeOut = Config.TIME_OUT)
        {
            var url = chapter4_1_1Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/pay/partner/transactions/jsapi");
            TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
            return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
        }




        /// <summary>
        /// 关闭订单
        /// </summary>
        /// <param name="data">关闭订单需要 POST的Data数据</param>
        /// <param name="timeOut"></param>
        /// <returns></returns>
        public async Task<ResultJsonBase> chapter4_1_3Async(chapter4_1_3RequestData data, int timeOut = Config.TIME_OUT)
        {
            var url = chapter4_1_3Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/pay/partner/transactions/out-trade-no/{out_trade_no}/close");
            TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
            return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
        }



        /// <summary>
        /// 申请退款
        /// </summary>
        /// <param name="data">申请退款需要POST的Data数据</param>
        /// <param name="timeOut"></param>
        /// <returns></returns>
        public async Task<ResultJsonBase> chapter4_1_9Async(chapter4_1_9RequestData data, int timeOut = Config.TIME_OUT)
        {
            var url = chapter4_1_9Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/refund/domestic/refunds");
            TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
            return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
        }



        /// <summary>
        /// 查询单笔退款
        /// </summary>
        /// <param name="data">查询单笔退款需要GET的Data数据</param>
        /// <param name="timeOut"></param>
        /// <returns></returns>
        public async Task<ResultJsonBase> chapter4_1_10Async(chapter4_1_10RequestData data, int timeOut = Config.TIME_OUT)
        {
            var url = chapter4_1_10Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/refund/domestic/refunds/{out_refund_no}");
            TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
            return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.GET, checkSign: false);
        }




        /// <summary>
        /// 申请交易账单
        /// </summary>
        /// <param name="data">申请交易账单需要GET的Data数据</param>
        /// <param name="timeOut"></param>
        /// <returns></returns>
        public async Task<ResultJsonBase> chapter4_1_6Async(chapter4_1_6RequestData data, int timeOut = Config.TIME_OUT)
        {
            var url = chapter4_1_6Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/bill/tradebill");
            TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
            return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.GET, checkSign: false);
        }



        /// <summary>
        /// 申请资金账单
        /// </summary>
        /// <param name="data">申请资金账单需要GET的Data数据</param>
        /// <param name="timeOut"></param>
        /// <returns></returns>
        public async Task<ResultJsonBase> chapter4_1_7Async(chapter4_1_7RequestData data, int timeOut = Config.TIME_OUT)
        {
            var url = chapter4_1_7Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/bill/fundflowbill");
            TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
            return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.GET, checkSign: false);
        }



        /// <summary>
        /// 申请单个子商户资金账单 
        /// </summary>
        /// <param name="data">申请单个子商户资金账单 需要GET的Data数据</param>
        /// <param name="timeOut"></param>
        /// <returns></returns>
        public async Task<ResultJsonBase> chapter4_1_12Async(chapter4_1_12RequestData data, int timeOut = Config.TIME_OUT)
        {
            var url = chapter4_1_12Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/bill/sub-merchant-fundflowbill");
            TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
            return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.GET, checkSign: false);
        }



        #endregion


        #region APP支付



        /// <summary>
        /// APP下单
        /// </summary>
        /// <param name="data">APP下单需要POST的Data数据</param>
        /// <param name="timeOut"></param>
        /// <returns></returns>
        public async Task<ResultJsonBase> chapter4_2_1Async(chapter4_2_1RequestData data, int timeOut = Config.TIME_OUT)
        {
            var url = chapter4_2_1Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/pay/partner/transactions/app");
            TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
            return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
        }




        /// <summary>
        /// 关闭订单
        /// </summary>
        /// <param name="data">关闭订单需要 POST的Data数据</param>
        /// <param name="timeOut"></param>
        /// <returns></returns>
        public async Task<ResultJsonBase> chapter4_2_3Async(chapter4_2_3RequestData data, int timeOut = Config.TIME_OUT)
        {
            var url = chapter4_2_3Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/pay/partner/transactions/out-trade-no/{out_trade_no}/close");
            TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
            return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
        }





        /// <summary>
        /// 申请退款
        /// </summary>
        /// <param name="data">申请退款需要POST的Data数据</param>
        /// <param name="timeOut"></param>
        /// <returns></returns>
        public async Task<ResultJsonBase> chapter4_2_9Async(chapter4_2_9RequestData data, int timeOut = Config.TIME_OUT)
        {
            var url = chapter4_2_9Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/refund/domestic/refunds");
            TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
            return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
        }



        /// <summary>
        /// 查询单笔退款
        /// </summary>
        /// <param name="data">查询单笔退款需要GET的Data数据</param>
        /// <param name="timeOut"></param>
        /// <returns></returns>
        public async Task<ResultJsonBase> chapter4_2_10Async(chapter4_2_10RequestData data, int timeOut = Config.TIME_OUT)
        {
            var url = chapter4_2_10Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/refund/domestic/refunds/{out_refund_no}");
            TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
            return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.GET, checkSign: false);
        }




        /// <summary>
        /// 申请交易账单
        /// </summary>
        /// <param name="data">申请交易账单需要GET的Data数据</param>
        /// <param name="timeOut"></param>
        /// <returns></returns>
        public async Task<ResultJsonBase> chapter4_2_6Async(chapter4_2_6RequestData data, int timeOut = Config.TIME_OUT)
        {
            var url = chapter4_2_6Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/bill/tradebill");
            TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
            return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.GET, checkSign: false);
        }



        /// <summary>
        /// 申请资金账单
        /// </summary>
        /// <param name="data">申请资金账单需要GET的Data数据</param>
        /// <param name="timeOut"></param>
        /// <returns></returns>
        public async Task<ResultJsonBase> chapter4_2_7Async(chapter4_2_7RequestData data, int timeOut = Config.TIME_OUT)
        {
            var url = chapter4_2_7Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/bill/fundflowbill");
            TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
            return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.GET, checkSign: false);
        }



        /// <summary>
        /// 申请单个子商户资金账单 
        /// </summary>
        /// <param name="data">申请单个子商户资金账单 需要GET的Data数据</param>
        /// <param name="timeOut"></param>
        /// <returns></returns>
        public async Task<ResultJsonBase> chapter4_2_12Async(chapter4_2_12RequestData data, int timeOut = Config.TIME_OUT)
        {
            var url = chapter4_2_12Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/bill/sub-merchant-fundflowbill");
            TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
            return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.GET, checkSign: false);
        }



        #endregion


        #region H5支付



        /// <summary>
        /// H5下单
        /// </summary>
        /// <param name="data">H5下单需要POST的Data数据</param>
        /// <param name="timeOut"></param>
        /// <returns></returns>
        public async Task<ResultJsonBase> chapter4_3_1Async(chapter4_3_1RequestData data, int timeOut = Config.TIME_OUT)
        {
            var url = chapter4_3_1Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/pay/partner/transactions/h5");
            TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
            return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
        }




        /// <summary>
        /// 关闭订单
        /// </summary>
        /// <param name="data">关闭订单需要 POST的Data数据</param>
        /// <param name="timeOut"></param>
        /// <returns></returns>
        public async Task<ResultJsonBase> chapter4_3_3Async(chapter4_3_3RequestData data, int timeOut = Config.TIME_OUT)
        {
            var url = chapter4_3_3Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/pay/partner/transactions/out-trade-no/{out_trade_no}/close");
            TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
            return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
        }





        /// <summary>
        /// 申请退款
        /// </summary>
        /// <param name="data">申请退款需要POST的Data数据</param>
        /// <param name="timeOut"></param>
        /// <returns></returns>
        public async Task<ResultJsonBase> chapter4_3_9Async(chapter4_3_9RequestData data, int timeOut = Config.TIME_OUT)
        {
            var url = chapter4_3_9Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/refund/domestic/refunds");
            TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
            return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
        }



        /// <summary>
        /// 查询单笔退款
        /// </summary>
        /// <param name="data">查询单笔退款需要GET的Data数据</param>
        /// <param name="timeOut"></param>
        /// <returns></returns>
        public async Task<ResultJsonBase> chapter4_3_10Async(chapter4_3_10RequestData data, int timeOut = Config.TIME_OUT)
        {
            var url = chapter4_3_10Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/refund/domestic/refunds/{out_refund_no}");
            TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
            return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.GET, checkSign: false);
        }




        /// <summary>
        /// 申请交易账单
        /// </summary>
        /// <param name="data">申请交易账单需要GET的Data数据</param>
        /// <param name="timeOut"></param>
        /// <returns></returns>
        public async Task<ResultJsonBase> chapter4_3_6Async(chapter4_3_6RequestData data, int timeOut = Config.TIME_OUT)
        {
            var url = chapter4_3_6Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/bill/tradebill");
            TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
            return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.GET, checkSign: false);
        }



        /// <summary>
        /// 申请资金账单
        /// </summary>
        /// <param name="data">申请资金账单需要GET的Data数据</param>
        /// <param name="timeOut"></param>
        /// <returns></returns>
        public async Task<ResultJsonBase> chapter4_3_7Async(chapter4_3_7RequestData data, int timeOut = Config.TIME_OUT)
        {
            var url = chapter4_3_7Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/bill/fundflowbill");
            TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
            return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.GET, checkSign: false);
        }



        /// <summary>
        /// 申请单个子商户资金账单 
        /// </summary>
        /// <param name="data">申请单个子商户资金账单 需要GET的Data数据</param>
        /// <param name="timeOut"></param>
        /// <returns></returns>
        public async Task<ResultJsonBase> chapter4_3_12Async(chapter4_3_12RequestData data, int timeOut = Config.TIME_OUT)
        {
            var url = chapter4_3_12Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/bill/sub-merchant-fundflowbill");
            TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
            return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.GET, checkSign: false);
        }



        #endregion


        #region Native支付



        /// <summary>
        /// Native下单
        /// </summary>
        /// <param name="data">Native下单需要POST的Data数据</param>
        /// <param name="timeOut"></param>
        /// <returns></returns>
        public async Task<ResultJsonBase> chapter4_4_1Async(chapter4_4_1RequestData data, int timeOut = Config.TIME_OUT)
        {
            var url = chapter4_4_1Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/pay/partner/transactions/native");
            TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
            return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
        }




        /// <summary>
        /// 关闭订单
        /// </summary>
        /// <param name="data">关闭订单需要 POST的Data数据</param>
        /// <param name="timeOut"></param>
        /// <returns></returns>
        public async Task<ResultJsonBase> chapter4_4_3Async(chapter4_4_3RequestData data, int timeOut = Config.TIME_OUT)
        {
            var url = chapter4_4_3Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/pay/partner/transactions/out-trade-no/{out_trade_no}/close");
            TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
            return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
        }





        /// <summary>
        /// 申请退款
        /// </summary>
        /// <param name="data">申请退款需要POST的Data数据</param>
        /// <param name="timeOut"></param>
        /// <returns></returns>
        public async Task<ResultJsonBase> chapter4_4_9Async(chapter4_4_9RequestData data, int timeOut = Config.TIME_OUT)
        {
            var url = chapter4_4_9Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/refund/domestic/refunds");
            TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
            return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
        }



        /// <summary>
        /// 查询单笔退款
        /// </summary>
        /// <param name="data">查询单笔退款需要GET的Data数据</param>
        /// <param name="timeOut"></param>
        /// <returns></returns>
        public async Task<ResultJsonBase> chapter4_4_10Async(chapter4_4_10RequestData data, int timeOut = Config.TIME_OUT)
        {
            var url = chapter4_4_10Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/refund/domestic/refunds/{out_refund_no}");
            TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
            return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.GET, checkSign: false);
        }




        /// <summary>
        /// 申请交易账单
        /// </summary>
        /// <param name="data">申请交易账单需要GET的Data数据</param>
        /// <param name="timeOut"></param>
        /// <returns></returns>
        public async Task<ResultJsonBase> chapter4_4_6Async(chapter4_4_6RequestData data, int timeOut = Config.TIME_OUT)
        {
            var url = chapter4_4_6Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/bill/tradebill");
            TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
            return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.GET, checkSign: false);
        }



        /// <summary>
        /// 申请资金账单
        /// </summary>
        /// <param name="data">申请资金账单需要GET的Data数据</param>
        /// <param name="timeOut"></param>
        /// <returns></returns>
        public async Task<ResultJsonBase> chapter4_4_7Async(chapter4_4_7RequestData data, int timeOut = Config.TIME_OUT)
        {
            var url = chapter4_4_7Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/bill/fundflowbill");
            TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
            return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.GET, checkSign: false);
        }



        /// <summary>
        /// 申请单个子商户资金账单 
        /// </summary>
        /// <param name="data">申请单个子商户资金账单 需要GET的Data数据</param>
        /// <param name="timeOut"></param>
        /// <returns></returns>
        public async Task<ResultJsonBase> chapter4_4_12Async(chapter4_4_12RequestData data, int timeOut = Config.TIME_OUT)
        {
            var url = chapter4_4_12Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/bill/sub-merchant-fundflowbill");
            TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
            return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.GET, checkSign: false);
        }



        #endregion


        #region 小程序支付



        /// <summary>
        /// JSAPI下单
        /// </summary>
        /// <param name="data">JSAPI下单需要POST的Data数据</param>
        /// <param name="timeOut"></param>
        /// <returns></returns>
        public async Task<ResultJsonBase> chapter4_5_1Async(chapter4_5_1RequestData data, int timeOut = Config.TIME_OUT)
        {
            var url = chapter4_5_1Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/pay/partner/transactions/jsapi");
            TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
            return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
        }




        /// <summary>
        /// 关闭订单
        /// </summary>
        /// <param name="data">关闭订单需要 POST的Data数据</param>
        /// <param name="timeOut"></param>
        /// <returns></returns>
        public async Task<ResultJsonBase> chapter4_5_3Async(chapter4_5_3RequestData data, int timeOut = Config.TIME_OUT)
        {
            var url = chapter4_5_3Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/pay/partner/transactions/out-trade-no/{out_trade_no}/close");
            TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
            return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
        }





        /// <summary>
        /// 申请退款
        /// </summary>
        /// <param name="data">申请退款需要POST的Data数据</param>
        /// <param name="timeOut"></param>
        /// <returns></returns>
        public async Task<ResultJsonBase> chapter4_5_9Async(chapter4_5_9RequestData data, int timeOut = Config.TIME_OUT)
        {
            var url = chapter4_5_9Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/refund/domestic/refunds");
            TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
            return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
        }



        /// <summary>
        /// 查询单笔退款
        /// </summary>
        /// <param name="data">查询单笔退款需要GET的Data数据</param>
        /// <param name="timeOut"></param>
        /// <returns></returns>
        public async Task<ResultJsonBase> chapter4_5_10Async(chapter4_5_10RequestData data, int timeOut = Config.TIME_OUT)
        {
            var url = chapter4_5_10Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/refund/domestic/refunds/{out_refund_no}");
            TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
            return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.GET, checkSign: false);
        }




        /// <summary>
        /// 申请交易账单
        /// </summary>
        /// <param name="data">申请交易账单需要GET的Data数据</param>
        /// <param name="timeOut"></param>
        /// <returns></returns>
        public async Task<ResultJsonBase> chapter4_5_6Async(chapter4_5_6RequestData data, int timeOut = Config.TIME_OUT)
        {
            var url = chapter4_5_6Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/bill/tradebill");
            TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
            return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.GET, checkSign: false);
        }



        /// <summary>
        /// 申请资金账单
        /// </summary>
        /// <param name="data">申请资金账单需要GET的Data数据</param>
        /// <param name="timeOut"></param>
        /// <returns></returns>
        public async Task<ResultJsonBase> chapter4_5_7Async(chapter4_5_7RequestData data, int timeOut = Config.TIME_OUT)
        {
            var url = chapter4_5_7Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/bill/fundflowbill");
            TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
            return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.GET, checkSign: false);
        }



        /// <summary>
        /// 申请单个子商户资金账单 
        /// </summary>
        /// <param name="data">申请单个子商户资金账单 需要GET的Data数据</param>
        /// <param name="timeOut"></param>
        /// <returns></returns>
        public async Task<ResultJsonBase> chapter4_5_12Async(chapter4_5_12RequestData data, int timeOut = Config.TIME_OUT)
        {
            var url = chapter4_5_12Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/bill/sub-merchant-fundflowbill");
            TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
            return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.GET, checkSign: false);
        }



        #endregion


        #region 合单支付



        /// <summary>
        /// 合单APP下单
        /// </summary>
        /// <param name="data">合单APP下单需要POST的Data数据</param>
        /// <param name="timeOut"></param>
        /// <returns></returns>
        public async Task<ResultJsonBase> chapter5_1_1Async(chapter5_1_1RequestData data, int timeOut = Config.TIME_OUT)
        {
            var url = chapter5_1_1Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/combine-transactions/app");
            TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
            return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
        }



        /// <summary>
        /// 合单H5下单
        /// </summary>
        /// <param name="data">合单H5下单需要POST的Data数据</param>
        /// <param name="timeOut"></param>
        /// <returns></returns>
        public async Task<ResultJsonBase> chapter5_1_2Async(chapter5_1_2RequestData data, int timeOut = Config.TIME_OUT)
        {
            var url = chapter5_1_2Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/combine-transactions/h5");
            TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
            return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
        }



        /// <summary>
        /// 合单JSAPI下单
        /// </summary>
        /// <param name="data">合单JSAPI下单需要POST的Data数据</param>
        /// <param name="timeOut"></param>
        /// <returns></returns>
        public async Task<ResultJsonBase> chapter5_1_3Async(chapter5_1_3RequestData data, int timeOut = Config.TIME_OUT)
        {
            var url = chapter5_1_3Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/combine-transactions/jsapi");
            TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
            return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
        }



        /// <summary>
        /// 合单小程序下单
        /// </summary>
        /// <param name="data">合单小程序下单需要POST的Data数据</param>
        /// <param name="timeOut"></param>
        /// <returns></returns>
        public async Task<ResultJsonBase> chapter5_1_4Async(chapter5_1_4RequestData data, int timeOut = Config.TIME_OUT)
        {
            var url = chapter5_1_4Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/combine-transactions/jsapi");
            TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
            return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
        }



        /// <summary>
        /// 合单Native下单
        /// </summary>
        /// <param name="data">合单Native下单需要POST的Data数据</param>
        /// <param name="timeOut"></param>
        /// <returns></returns>
        public async Task<ResultJsonBase> chapter5_1_5Async(chapter5_1_5RequestData data, int timeOut = Config.TIME_OUT)
        {
            var url = chapter5_1_5Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/combine-transactions/native");
            TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
            return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
        }








        /// <summary>
        /// 合单查询订单
        /// </summary>
        /// <param name="data">合单查询订单需要GET的Data数据</param>
        /// <param name="timeOut"></param>
        /// <returns></returns>
        public async Task<ResultJsonBase> chapter5_1_11Async(chapter5_1_11RequestData data, int timeOut = Config.TIME_OUT)
        {
            var url = chapter5_1_11Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/combine-transactions/out-trade-no/{combine_out_trade_no}");
            TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
            return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.GET, checkSign: false);
        }



        /// <summary>
        /// 合单关闭订单
        /// </summary>
        /// <param name="data">合单关闭订单需要POST的Data数据</param>
        /// <param name="timeOut"></param>
        /// <returns></returns>
        public async Task<ResultJsonBase> chapter5_1_12Async(chapter5_1_12RequestData data, int timeOut = Config.TIME_OUT)
        {
            var url = chapter5_1_12Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/combine-transactions/out-trade-no/{combine_out_trade_no}/close");
            TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
            return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
        }




        /// <summary>
        /// 申请退款
        /// </summary>
        /// <param name="data">申请退款需要POST的Data数据</param>
        /// <param name="timeOut"></param>
        /// <returns></returns>
        public async Task<ResultJsonBase> chapter5_1_14Async(chapter5_1_14RequestData data, int timeOut = Config.TIME_OUT)
        {
            var url = chapter5_1_14Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/refund/domestic/refunds");
            TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
            return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
        }



        /// <summary>
        /// 查询单笔退款
        /// </summary>
        /// <param name="data">查询单笔退款需要GET的Data数据</param>
        /// <param name="timeOut"></param>
        /// <returns></returns>
        public async Task<ResultJsonBase> chapter5_1_15Async(chapter5_1_15RequestData data, int timeOut = Config.TIME_OUT)
        {
            var url = chapter5_1_15Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/refund/domestic/refunds/{out_refund_no}");
            TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
            return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.GET, checkSign: false);
        }




        /// <summary>
        /// 申请交易账单
        /// </summary>
        /// <param name="data">申请交易账单需要GET的Data数据</param>
        /// <param name="timeOut"></param>
        /// <returns></returns>
        public async Task<ResultJsonBase> chapter5_1_17Async(chapter5_1_17RequestData data, int timeOut = Config.TIME_OUT)
        {
            var url = chapter5_1_17Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/bill/tradebill");
            TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
            return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.GET, checkSign: false);
        }



        /// <summary>
        /// 申请资金账单
        /// </summary>
        /// <param name="data">申请资金账单需要GET的Data数据</param>
        /// <param name="timeOut"></param>
        /// <returns></returns>
        public async Task<ResultJsonBase> chapter5_1_18Async(chapter5_1_18RequestData data, int timeOut = Config.TIME_OUT)
        {
            var url = chapter5_1_18Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/bill/fundflowbill");
            TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
            return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.GET, checkSign: false);
        }



        /// <summary>
        /// 申请单个子商户资金账单 
        /// </summary>
        /// <param name="data">申请单个子商户资金账单 需要GET的Data数据</param>
        /// <param name="timeOut"></param>
        /// <returns></returns>
        public async Task<ResultJsonBase> chapter5_1_20Async(chapter5_1_20RequestData data, int timeOut = Config.TIME_OUT)
        {
            var url = chapter5_1_20Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/bill/sub-merchant-fundflowbill");
            TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
            return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.GET, checkSign: false);
        }



        #endregion

    }
}

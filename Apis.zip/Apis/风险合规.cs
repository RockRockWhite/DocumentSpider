
        #region Apache License Version 2.0
        /*----------------------------------------------------------------

        Copyright 2022 Jeffrey Su & Suzhou Senparc Network Technology Co.,Ltd.

        Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file
        except in compliance with the License. You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

        Unless required by applicable law or agreed to in writing, software distributed under the
        License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
        either express or implied. See the License for the specific language governing permissions
        and limitations under the License.

        Detail: https://github.com/JeffreySu/WeiXinMPSDK/blob/master/license.md

        ----------------------------------------------------------------*/
        #endregion Apache License Version 2.0

        /*----------------------------------------------------------------
            Copyright (C) 2022 Senparc
        
            文件名：风险合规.cs
            文件功能描述：微信支付V3服务商平台接口
            
            创建标识：Senparc - 20220804

        ----------------------------------------------------------------*/

        using Senparc.CO2NET.Helpers;
        using Senparc.CO2NET.Trace;
        using Senparc.Weixin.Entities;
        // TODO: 引入Entities
        // using Senparc.Weixin.TenPayV3.Apis.BasePay;
        // using Senparc.Weixin.TenPayV3.Apis.Entities;
        // using Senparc.Weixin.TenPayV3.Entities;
        // using Senparc.Weixin.TenPayV3.Helpers;
        using System;
        using System.IO;
        using System.Linq;
        using System.Runtime.InteropServices.ComTypes;
        using System.Security.Cryptography;
        using System.Text;
        using System.Threading.Tasks;

        namespace Senparc.Weixin.ServiceProviderTenPayV3.Apis{
            public class 风险合规{

                private ISenparcWeixinSettingForTenpayV3 _tenpayV3Setting;

                /// <summary>
                /// 构造函数
                /// </summary>
                /// <param name="senparcWeixinSettingForTenpayV3"></param>
                public 风险合规(ISenparcWeixinSettingForTenpayV3 senparcWeixinSettingForTenpayV3 = null)
                {
                    _tenpayV3Setting = senparcWeixinSettingForTenpayV3 ?? Senparc.Weixin.Config.SenparcWeixinSetting.TenpayV3Setting;

                }

                /// <summary>
                /// 返回可用的微信支付地址（自动判断是否使用沙箱）
                /// </summary>
                /// <param name="urlFormat">如：<code>https://api.mch.weixin.qq.com/pay/unifiedorder</code></param>
                /// <returns></returns>
                internal static string GetPayApiUrl(string urlFormat)
                {
                    //注意：目前微信支付 V3 还没有支持沙箱，此处只是预留
                    return string.Format(urlFormat, Senparc.Weixin.Config.UseSandBoxPay ? "sandboxnew/" : "");
                }
            

            #region 商户开户意愿确认

            

            /// <summary>
            /// 提交申请单
            /// </summary>
            /// <param name="data">提交申请单需要POST的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter10_1_1Async(chapter10_1_1RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter10_1_1Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/apply4subject/applyment");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
            }
        


            /// <summary>
            /// 撤销申请单
            /// </summary>
            /// <param name="data">撤销申请单需要POST的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter10_1_2Async(chapter10_1_2RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter10_1_2Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/apply4subject/applyment/{business_code}/cancel");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
            }
        


            /// <summary>
            /// 查询申请单审核结果
            /// </summary>
            /// <param name="data">查询申请单审核结果需要GET的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter10_1_3Async(chapter10_1_3RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter10_1_3Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/apply4subject/applyment");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.GET, checkSign: false);
            }
        


            /// <summary>
            /// 获取商户开户意愿确认状态
            /// </summary>
            /// <param name="data">获取商户开户意愿确认状态需要GET的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter10_1_4Async(chapter10_1_4RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter10_1_4Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/apply4subject/applyment/merchants/{sub_mchid}/state");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.GET, checkSign: false);
            }
        

            #endregion

            
            #region 消费者投诉2.0

            

            /// <summary>
            /// 查询投诉单列表
            /// </summary>
            /// <param name="data">查询投诉单列表需要GET的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter10_2_11Async(chapter10_2_11RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter10_2_11Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/merchant-service/complaints-v2");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.GET, checkSign: false);
            }
        


            /// <summary>
            /// 查询投诉单详情
            /// </summary>
            /// <param name="data">查询投诉单详情需要GET的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter10_2_13Async(chapter10_2_13RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter10_2_13Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/merchant-service/complaints-v2/{complaint_id}");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.GET, checkSign: false);
            }
        


            /// <summary>
            /// 查询投诉协商历史
            /// </summary>
            /// <param name="data">查询投诉协商历史需要GET的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter10_2_12Async(chapter10_2_12RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter10_2_12Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/merchant-service/complaints-v2/{complaint_id}/negotiation-historys");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.GET, checkSign: false);
            }
        



            /// <summary>
            /// 创建投诉通知回调地址
            /// </summary>
            /// <param name="data">创建投诉通知回调地址需要POST的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter10_2_2Async(chapter10_2_2RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter10_2_2Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/merchant-service/complaint-notifications");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
            }
        


            /// <summary>
            /// 查询投诉通知回调地址
            /// </summary>
            /// <param name="data">查询投诉通知回调地址需要GET的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter10_2_3Async(chapter10_2_3RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter10_2_3Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/merchant-service/complaint-notifications");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.GET, checkSign: false);
            }
        


            /// <summary>
            /// 更新投诉通知回调地址
            /// </summary>
            /// <param name="data">更新投诉通知回调地址需要PUT的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter10_2_4Async(chapter10_2_4RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter10_2_4Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/merchant-service/complaint-notifications");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.PUT, checkSign: false);
            }
        


            /// <summary>
            /// 删除投诉通知回调地址
            /// </summary>
            /// <param name="data">删除投诉通知回调地址需要DELETE的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter10_2_5Async(chapter10_2_5RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter10_2_5Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/merchant-service/complaint-notifications");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.DELETE, checkSign: false);
            }
        


            /// <summary>
            /// 回复用户
            /// </summary>
            /// <param name="data">回复用户需要POST的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter10_2_14Async(chapter10_2_14RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter10_2_14Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/merchant-service/complaints-v2/{complaint_id}/response");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
            }
        


            /// <summary>
            /// 反馈处理完成
            /// </summary>
            /// <param name="data">反馈处理完成需要POST的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter10_2_15Async(chapter10_2_15RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter10_2_15Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/merchant-service/complaints-v2/{complaint_id}/complete");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
            }
        


            /// <summary>
            /// 更新退款审批结果
            /// </summary>
            /// <param name="data">更新退款审批结果需要POST的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter10_2_19Async(chapter10_2_19RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter10_2_19Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/merchant-service/complaints-v2/{complaint_id}/update-refund-progress");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
            }
        


            /// <summary>
            /// 商户上传反馈图片
            /// </summary>
            /// <param name="data">商户上传反馈图片需要multipart/form-data的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter10_2_10Async(chapter10_2_10RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter10_2_10Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/merchant-service/images/upload");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.multipart/form-data, checkSign: false);
            }
        


            #endregion

            
            #region 商户违规通知回调

            

            /// <summary>
            ///  创建商户违规通知回调地址
            /// </summary>
            /// <param name="data"> 创建商户违规通知回调地址需要POST的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter10_3_1Async(chapter10_3_1RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter10_3_1Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/merchant-risk-manage/violation-notifications");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
            }
        


            /// <summary>
            ///  查询商户违规通知回调地址
            /// </summary>
            /// <param name="data"> 查询商户违规通知回调地址需要GET的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter10_3_2Async(chapter10_3_2RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter10_3_2Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/merchant-risk-manage/violation-notifications");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.GET, checkSign: false);
            }
        


            /// <summary>
            ///  修改商户违规通知回调地址
            /// </summary>
            /// <param name="data"> 修改商户违规通知回调地址需要PUT的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter10_3_3Async(chapter10_3_3RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter10_3_3Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/merchant-risk-manage/violation-notifications");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.PUT, checkSign: false);
            }
        


            /// <summary>
            ///  删除商户违规通知回调地址
            /// </summary>
            /// <param name="data"> 删除商户违规通知回调地址需要DELETE的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter10_3_4Async(chapter10_3_4RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter10_3_4Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/merchant-risk-manage/violation-notifications");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.DELETE, checkSign: false);
            }
        


            #endregion

            }
}

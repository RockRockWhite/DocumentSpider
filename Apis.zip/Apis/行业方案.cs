
        #region Apache License Version 2.0
        /*----------------------------------------------------------------

        Copyright 2022 Jeffrey Su & Suzhou Senparc Network Technology Co.,Ltd.

        Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file
        except in compliance with the License. You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

        Unless required by applicable law or agreed to in writing, software distributed under the
        License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
        either express or implied. See the License for the specific language governing permissions
        and limitations under the License.

        Detail: https://github.com/JeffreySu/WeiXinMPSDK/blob/master/license.md

        ----------------------------------------------------------------*/
        #endregion Apache License Version 2.0

        /*----------------------------------------------------------------
            Copyright (C) 2022 Senparc
        
            文件名：行业方案.cs
            文件功能描述：微信支付V3服务商平台接口
            
            创建标识：Senparc - 20220804

        ----------------------------------------------------------------*/

        using Senparc.CO2NET.Helpers;
        using Senparc.CO2NET.Trace;
        using Senparc.Weixin.Entities;
        // TODO: 引入Entities
        // using Senparc.Weixin.TenPayV3.Apis.BasePay;
        // using Senparc.Weixin.TenPayV3.Apis.Entities;
        // using Senparc.Weixin.TenPayV3.Entities;
        // using Senparc.Weixin.TenPayV3.Helpers;
        using System;
        using System.IO;
        using System.Linq;
        using System.Runtime.InteropServices.ComTypes;
        using System.Security.Cryptography;
        using System.Text;
        using System.Threading.Tasks;

        namespace Senparc.Weixin.ServiceProviderTenPayV3.Apis{
            public class 行业方案{

                private ISenparcWeixinSettingForTenpayV3 _tenpayV3Setting;

                /// <summary>
                /// 构造函数
                /// </summary>
                /// <param name="senparcWeixinSettingForTenpayV3"></param>
                public 行业方案(ISenparcWeixinSettingForTenpayV3 senparcWeixinSettingForTenpayV3 = null)
                {
                    _tenpayV3Setting = senparcWeixinSettingForTenpayV3 ?? Senparc.Weixin.Config.SenparcWeixinSetting.TenpayV3Setting;

                }

                /// <summary>
                /// 返回可用的微信支付地址（自动判断是否使用沙箱）
                /// </summary>
                /// <param name="urlFormat">如：<code>https://api.mch.weixin.qq.com/pay/unifiedorder</code></param>
                /// <returns></returns>
                internal static string GetPayApiUrl(string urlFormat)
                {
                    //注意：目前微信支付 V3 还没有支持沙箱，此处只是预留
                    return string.Format(urlFormat, Senparc.Weixin.Config.UseSandBoxPay ? "sandboxnew/" : "");
                }
            

            #region 电商收付通（商户进件） 

            

            /// <summary>
            /// 二级商户进件
            /// </summary>
            /// <param name="data">二级商户进件需要POST的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter7_1_1Async(chapter7_1_1RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter7_1_1Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/ecommerce/applyments/");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
            }
        



            /// <summary>
            /// 下载平台证书
            /// </summary>
            /// <param name="data">下载平台证书需要GET的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter7_1_3Async(chapter7_1_3RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter7_1_3Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/certificates");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.GET, checkSign: false);
            }
        


            /// <summary>
            /// 修改结算账号
            /// </summary>
            /// <param name="data">修改结算账号需要POST的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter7_1_4Async(chapter7_1_4RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter7_1_4Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/apply4sub/sub_merchants/{sub_mchid}/modify-settlement");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
            }
        


            /// <summary>
            /// 查询结算账号
            /// </summary>
            /// <param name="data">查询结算账号需要GET的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter7_1_5Async(chapter7_1_5RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter7_1_5Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/apply4sub/sub_merchants/{sub_mchid}/settlement");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.GET, checkSign: false);
            }
        

            #endregion

            
            #region 电商收付通（普通支付） 

            

            /// <summary>
            /// APP下单
            /// </summary>
            /// <param name="data">APP下单需要POST的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter7_2_1Async(chapter7_2_1RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter7_2_1Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/pay/partner/transactions/app");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
            }
        


            /// <summary>
            /// JSAPI下单
            /// </summary>
            /// <param name="data">JSAPI下单需要POST的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter7_2_2Async(chapter7_2_2RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter7_2_2Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/pay/partner/transactions/jsapi");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
            }
        


            /// <summary>
            /// 小程序下单
            /// </summary>
            /// <param name="data">小程序下单需要POST的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter7_2_3Async(chapter7_2_3RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter7_2_3Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/pay/partner/transactions/jsapi");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
            }
        


            /// <summary>
            /// H5下单
            /// </summary>
            /// <param name="data">H5下单需要POST的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter7_2_4Async(chapter7_2_4RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter7_2_4Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/pay/partner/transactions/h5");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
            }
        


            /// <summary>
            /// Native下单
            /// </summary>
            /// <param name="data">Native下单需要POST的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter7_2_12Async(chapter7_2_12RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter7_2_12Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/pay/partner/transactions/native");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
            }
        



            /// <summary>
            /// 关闭订单
            /// </summary>
            /// <param name="data">关闭订单需要 POST的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter7_2_6Async(chapter7_2_6RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter7_2_6Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/pay/partner/transactions/out-trade-no/{out_trade_no}/close");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod. POST, checkSign: false);
            }
        







            #endregion

            
            #region 电商收付通（合单支付） 

            

            /// <summary>
            /// 合单APP下单
            /// </summary>
            /// <param name="data">合单APP下单需要POST的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter7_3_1Async(chapter7_3_1RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter7_3_1Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/combine-transactions/app");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
            }
        


            /// <summary>
            /// 合单H5下单
            /// </summary>
            /// <param name="data">合单H5下单需要POST的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter7_3_2Async(chapter7_3_2RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter7_3_2Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/combine-transactions/h5");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
            }
        


            /// <summary>
            /// 合单JSAPI下单
            /// </summary>
            /// <param name="data">合单JSAPI下单需要POST的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter7_3_3Async(chapter7_3_3RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter7_3_3Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/combine-transactions/jsapi");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
            }
        


            /// <summary>
            /// 合单小程序下单
            /// </summary>
            /// <param name="data">合单小程序下单需要POST的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter7_3_4Async(chapter7_3_4RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter7_3_4Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/combine-transactions/jsapi");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
            }
        


            /// <summary>
            /// 合单Native下单
            /// </summary>
            /// <param name="data">合单Native下单需要POST的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter7_3_5Async(chapter7_3_5RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter7_3_5Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/combine-transactions/native");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
            }
        







            /// <summary>
            /// 合单查询订单
            /// </summary>
            /// <param name="data">合单查询订单需要GET的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter7_3_11Async(chapter7_3_11RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter7_3_11Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/combine-transactions/out-trade-no/{combine_out_trade_no}");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.GET, checkSign: false);
            }
        


            /// <summary>
            /// 合单关闭订单
            /// </summary>
            /// <param name="data">合单关闭订单需要POST的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter7_3_12Async(chapter7_3_12RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter7_3_12Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/combine-transactions/out-trade-no/{combine_out_trade_no}/close");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
            }
        


            #endregion

            
            #region 电商收付通（分账） 

            

            /// <summary>
            /// 请求分账
            /// </summary>
            /// <param name="data">请求分账需要POST的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter7_4_1Async(chapter7_4_1RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter7_4_1Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/ecommerce/profitsharing/orders");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
            }
        


            /// <summary>
            /// 查询分账结果
            /// </summary>
            /// <param name="data">查询分账结果需要GET的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter7_4_2Async(chapter7_4_2RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter7_4_2Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/ecommerce/profitsharing/orders");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.GET, checkSign: false);
            }
        


            /// <summary>
            /// 请求分账回退
            /// </summary>
            /// <param name="data">请求分账回退需要POST的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter7_4_3Async(chapter7_4_3RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter7_4_3Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/ecommerce/profitsharing/returnorders");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
            }
        


            /// <summary>
            /// 查询分账回退结果
            /// </summary>
            /// <param name="data">查询分账回退结果需要GET的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter7_4_4Async(chapter7_4_4RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter7_4_4Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/ecommerce/profitsharing/returnorders");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.GET, checkSign: false);
            }
        


            /// <summary>
            /// 完结分账
            /// </summary>
            /// <param name="data">完结分账需要POST的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter7_4_5Async(chapter7_4_5RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter7_4_5Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/ecommerce/profitsharing/finish-order");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
            }
        


            /// <summary>
            /// 查询订单剩余待分金额
            /// </summary>
            /// <param name="data">查询订单剩余待分金额需要GET的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter7_4_9Async(chapter7_4_9RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter7_4_9Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/ecommerce/profitsharing/orders/{transaction_id}/amounts");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.GET, checkSign: false);
            }
        


            /// <summary>
            /// 添加分账接收方
            /// </summary>
            /// <param name="data">添加分账接收方需要POST的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter7_4_7Async(chapter7_4_7RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter7_4_7Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/ecommerce/profitsharing/receivers/add");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
            }
        


            /// <summary>
            /// 删除分账接收方
            /// </summary>
            /// <param name="data">删除分账接收方需要POST的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter7_4_8Async(chapter7_4_8RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter7_4_8Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/ecommerce/profitsharing/receivers/delete");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
            }
        


            #endregion

            
            #region 电商收付通（补差） 

            

            /// <summary>
            /// 请求补差
            /// </summary>
            /// <param name="data">请求补差需要POST的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter7_5_1Async(chapter7_5_1RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter7_5_1Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/ecommerce/subsidies/create");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
            }
        


            /// <summary>
            /// 请求补差回退
            /// </summary>
            /// <param name="data">请求补差回退需要POST的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter7_5_2Async(chapter7_5_2RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter7_5_2Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/ecommerce/subsidies/return");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
            }
        


            /// <summary>
            /// 取消补差
            /// </summary>
            /// <param name="data">取消补差需要POST的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter7_5_3Async(chapter7_5_3RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter7_5_3Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/ecommerce/subsidies/cancel");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
            }
        

            #endregion

            
            #region 电商收付通（退款） 

            

            /// <summary>
            /// 申请退款
            /// </summary>
            /// <param name="data">申请退款需要POST的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter7_6_1Async(chapter7_6_1RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter7_6_1Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/ecommerce/refunds/apply");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
            }
        




            /// <summary>
            /// 垫付退款回补
            /// </summary>
            /// <param name="data">垫付退款回补需要POST的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter7_6_4Async(chapter7_6_4RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter7_6_4Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/ecommerce/refunds/{refund_id}/return-advance");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
            }
        


            /// <summary>
            /// 查询垫付回补结果
            /// </summary>
            /// <param name="data">查询垫付回补结果需要GET的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter7_6_5Async(chapter7_6_5RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter7_6_5Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/ecommerce/refunds/{refund_id}/return-advance");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.GET, checkSign: false);
            }
        

            #endregion

            
            #region 电商收付通（余额查询） 

            

            /// <summary>
            /// 查询二级商户账户实时余额
            /// </summary>
            /// <param name="data">查询二级商户账户实时余额需要GET的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter7_7_1Async(chapter7_7_1RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter7_7_1Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/ecommerce/fund/balance/{sub_mchid}");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.GET, checkSign: false);
            }
        


            /// <summary>
            /// 查询二级商户账户日终余额
            /// </summary>
            /// <param name="data">查询二级商户账户日终余额需要GET的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter7_7_2Async(chapter7_7_2RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter7_7_2Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/ecommerce/fund/enddaybalance/{sub_mchid}");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.GET, checkSign: false);
            }
        


            /// <summary>
            /// 查询电商平台账户实时余额
            /// </summary>
            /// <param name="data">查询电商平台账户实时余额需要GET的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter7_7_3Async(chapter7_7_3RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter7_7_3Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/merchant/fund/balance/{account_type}");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.GET, checkSign: false);
            }
        


            /// <summary>
            /// 查询电商平台账户日终余额
            /// </summary>
            /// <param name="data">查询电商平台账户日终余额需要GET的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter7_7_4Async(chapter7_7_4RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter7_7_4Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/merchant/fund/dayendbalance/{account_type}");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.GET, checkSign: false);
            }
        

            #endregion

            
            #region 电商收付通（商户提现） 

            

            /// <summary>
            /// 二级商户预约提现
            /// </summary>
            /// <param name="data">二级商户预约提现需要POST的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter7_8_2Async(chapter7_8_2RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter7_8_2Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/ecommerce/fund/withdraw");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
            }
        



            /// <summary>
            /// 电商平台预约提现
            /// </summary>
            /// <param name="data">电商平台预约提现需要POST的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter7_8_5Async(chapter7_8_5RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter7_8_5Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/merchant/fund/withdraw");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
            }
        



            /// <summary>
            /// 按日下载提现异常文件
            /// </summary>
            /// <param name="data">按日下载提现异常文件需要GET的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter7_8_4Async(chapter7_8_4RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter7_8_4Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/merchant/fund/withdraw/bill-type/{bill_type}");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.GET, checkSign: false);
            }
        

            #endregion

            
            #region 电商收付通（跨境付款）

            

            /// <summary>
            /// 查询订单剩余可出境余额
            /// </summary>
            /// <param name="data">查询订单剩余可出境余额需要GET的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter7_10_1Async(chapter7_10_1RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter7_10_1Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/funds-to-oversea/transactions/{transaction_id}/available_abroad_amounts");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.GET, checkSign: false);
            }
        


            /// <summary>
            /// 申请资金出境
            /// </summary>
            /// <param name="data">申请资金出境需要POST的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter7_10_2Async(chapter7_10_2RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter7_10_2Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/funds-to-oversea/orders");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
            }
        


            /// <summary>
            /// 查询出境结果
            /// </summary>
            /// <param name="data">查询出境结果需要GET的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter7_10_3Async(chapter7_10_3RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter7_10_3Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/funds-to-oversea/orders/{out_order_id}");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.GET, checkSign: false);
            }
        


            /// <summary>
            /// 获取购付汇账单文件下载链接
            /// </summary>
            /// <param name="data">获取购付汇账单文件下载链接需要GET的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter7_10_4Async(chapter7_10_4RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter7_10_4Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/funds-to-oversea/bill-download-url");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.GET, checkSign: false);
            }
        

            #endregion

            
            #region 电商收付通（下载账单） 

            

            /// <summary>
            /// 申请交易账单
            /// </summary>
            /// <param name="data">申请交易账单需要GET的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter7_9_1Async(chapter7_9_1RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter7_9_1Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/bill/tradebill");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.GET, checkSign: false);
            }
        


            /// <summary>
            /// 申请资金账单
            /// </summary>
            /// <param name="data">申请资金账单需要GET的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter7_9_2Async(chapter7_9_2RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter7_9_2Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/bill/fundflowbill");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.GET, checkSign: false);
            }
        


            /// <summary>
            /// 申请分账账单
            /// </summary>
            /// <param name="data">申请分账账单需要GET的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter7_9_6Async(chapter7_9_6RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter7_9_6Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/profitsharing/bills");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.GET, checkSign: false);
            }
        


            /// <summary>
            /// 申请二级商户资金账单
            /// </summary>
            /// <param name="data">申请二级商户资金账单需要GET的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter7_9_5Async(chapter7_9_5RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter7_9_5Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/ecommerce/bill/fundflowbill");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.GET, checkSign: false);
            }
        


            #endregion

            
            #region 智慧商圈 

            



            /// <summary>
            /// 商圈会员积分同步
            /// </summary>
            /// <param name="data">商圈会员积分同步需要POST的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter8_6_2Async(chapter8_6_2RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter8_6_2Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/businesscircle/points/notify");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
            }
        



            /// <summary>
            /// 商圈会员积分服务授权查询
            /// </summary>
            /// <param name="data">商圈会员积分服务授权查询需要GET的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter8_6_4Async(chapter8_6_4RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter8_6_4Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/businesscircle/user-authorizations/{openid}");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.GET, checkSign: false);
            }
        


            /// <summary>
            /// 商圈会员待积分状态查询
            /// </summary>
            /// <param name="data">商圈会员待积分状态查询需要get的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter8_6_7Async(chapter8_6_7RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter8_6_7Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/businesscircle/users/{openid}/points/commit_status");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.get, checkSign: false);
            }
        


            /// <summary>
            /// 商圈会员停车状态同步
            /// </summary>
            /// <param name="data">商圈会员停车状态同步需要post的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter8_6_5Async(chapter8_6_5RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter8_6_5Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/businesscircle/parkings");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.post, checkSign: false);
            }
        

            #endregion

            
            #region 微信支付分停车服务 

            

            /// <summary>
            /// 查询车牌服务开通信息
            /// </summary>
            /// <param name="data">查询车牌服务开通信息需要GET的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter8_8_1Async(chapter8_8_1RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter8_8_1Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/vehicle/parking/services/find");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.GET, checkSign: false);
            }
        


            /// <summary>
            /// 创建停车入场
            /// </summary>
            /// <param name="data">创建停车入场需要POST的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter8_8_2Async(chapter8_8_2RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter8_8_2Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/vehicle/parking/parkings");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
            }
        


            /// <summary>
            /// 扣费受理
            /// </summary>
            /// <param name="data">扣费受理需要POST的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter8_8_3Async(chapter8_8_3RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter8_8_3Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/vehicle/transactions/parking");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
            }
        


            /// <summary>
            /// 查询订单
            /// </summary>
            /// <param name="data">查询订单需要GET的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter8_8_4Async(chapter8_8_4RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter8_8_4Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/vehicle/transactions/out-trade-no/{out_trade_no}");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.GET, checkSign: false);
            }
        








            /// <summary>
            /// 申请退款
            /// </summary>
            /// <param name="data">申请退款需要POST的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter8_8_11Async(chapter8_8_11RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter8_8_11Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/refund/domestic/refunds");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.POST, checkSign: false);
            }
        



            /// <summary>
            /// 查询单笔退款
            /// </summary>
            /// <param name="data">查询单笔退款需要GET的Data数据</param>
            /// <param name="timeOut"></param>
            /// <returns></returns>
            public async Task<ResultJsonBase> chapter8_8_13Async(chapter8_8_13RequestData data, int timeOut = Config.TIME_OUT)
            {
                var url = chapter8_8_13Apis.GetPayApiUrl(Senparc.Weixin.Config.TenPayV3Host + "/v3/refund/domestic/refunds/{out_refund_no}");
                TenPayApiRequest tenPayApiRequest = new(_tenpayV3Setting);
                return await tenPayApiRequest.RequestAsync<ResultJsonBase>(url, data, timeOut, ApiRequestMethod.GET, checkSign: false);
            }
        

            #endregion

            }
}
